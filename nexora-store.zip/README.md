# NEXORA — Discover More. Live Better.

A responsive React + Vite storefront starter for a worldwide general-products dropshipping brand.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`
3. Run `npm run dev`
4. Open the local URL printed by Vite.

## Production build
Run `npm run build`. The deployable site is generated in `dist/`.

## Important launch checklist
This is a polished front-end starter, not yet a live commerce operation.
- Connect a payment provider available in your business country and target markets (for example Stripe or another supported provider).
- Implement a secure server-side order and payment flow. Never collect or store card details in this front end.
- Connect a supplier/fulfilment service and sync real product availability, costs, shipping estimates and tracking.
- Replace sample products, prices, descriptions and remote demo photography with supplier-approved product data and licensed images.
- Add accurate shipping, returns, privacy, terms, tax/VAT and contact information for your business.
- Configure a real support email, domain, analytics and consent controls.
- Test taxes, shipping zones, checkout, refunds, mobile UX and order notifications before accepting orders.

The checkout button is intentionally a demo and does not take payment. Newsletter submission is also a front-end demo.
